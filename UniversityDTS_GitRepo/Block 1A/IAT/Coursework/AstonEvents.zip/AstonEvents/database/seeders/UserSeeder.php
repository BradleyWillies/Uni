<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();

        echo "Generating users...\n";
        for ($i = 0 ; $i < 3 ; $i++) {
            User::create([
               'email' => $faker->safeEmail,
               'password' => Hash::make($faker->password)
            ]);
        }
        User::create([
            'email' => 'bob.smith@email.com',
            'password' => Hash::make('password')
        ]);
    }
}
