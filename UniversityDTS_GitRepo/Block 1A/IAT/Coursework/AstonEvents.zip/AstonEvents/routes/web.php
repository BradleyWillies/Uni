<?php

use App\Http\Controllers\Organiser\EventController;
use \App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [StudentController::class, 'index'])->name('student.event.index');
Route::get('/event/show/{id}', [StudentController::class, 'show'])->name('student.event.show');
Route::post('/event/show/{id}/addInterest', [StudentController::class, 'addInterest'])->name('student.event.addInterest');
Route::get('/event/contact/{id}', [StudentController::class, 'showContact'])->name('student.event.contact');
Route::post('/event/contact/{id}/sendMail', [StudentController::class, 'sendContactMail'])->name('student.event.contact.sendMail');

Route::group(['prefix' => '/dashboard', 'middleware' => ['auth']], function () {
    Route::get('', [EventController::class, 'index'])->name('dashboard.event.index');
    Route::get('/event/create', [EventController::class, 'create'])->name('dashboard.event.create');
    Route::post('/event/store', [EventController::class, 'store'])->name('dashboard.event.store');
    Route::get('/event/edit/{id}', [EventController::class, 'edit'])->name('dashboard.event.edit')->middleware('canEditEvent');
    Route::post('/event/update/{id}', [EventController::class, 'update'])->name('dashboard.event.update')->middleware('canEditEvent');
});

Auth::routes();
