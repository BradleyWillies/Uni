<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EventRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:1000',
            'location' => 'required|string|max:255',
            'event_category_id' => 'required|exists:event_categories,id',
            'date_time' => 'required|date',
            'images' => 'required',
            'images.*' => 'image|max:1024',
            'related_event_id' => 'nullable|exists:events,id',
            'web_source_url' => 'nullable|string|max:255'
        ];
    }

    public function attributes()
    {
        return [
            'name' => 'name',
            'description' => 'description',
            'location' => 'location',
            'event_category_id' => 'category',
            'date_time' => 'date/time',
            'images' => 'image(s)',
            'related_event_id' => 'related event',
            'web_source_url' => 'related website url'
        ];
    }
}
