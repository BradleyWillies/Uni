<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h3><?php echo e(('Welcome ' . auth()->user()->organiser->name)); ?></h3><br>
                    <?php if(count($events) > 0): ?>
                        <form method="GET" action="<?php echo e(route('dashboard.event.index')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="event_category_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Filter by category')); ?></label>

                                <div class="col-md-6">
                                    <select name="event_category_id" id="event_category_id">
                                        <option value="" ></option>
                                        <?php $__currentLoopData = $eventCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($eventCategory->id); ?>" <?php if(app('request')->input('event_category_id') == $eventCategory->id): ?> selected <?php endif; ?>><?php echo e($eventCategory->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="event_heading" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sort by heading')); ?></label>

                                <div class="col-md-3">
                                    <select name="event_heading" id="event_heading">
                                        <?php ($event_heading = app('request')->input('event_heading')); ?>
                                        <option value="" <?php if(!$event_heading || $event_heading == ""): ?> selected <?php endif; ?>></option>
                                        <option value="name" <?php if($event_heading == "name"): ?> selected <?php endif; ?>>Name</option>
                                        <option value="description" <?php if($event_heading == "description"): ?> selected <?php endif; ?>>Description</option>
                                        <option value="location" <?php if($event_heading == "location"): ?> selected <?php endif; ?>>Location</option>
                                        <option value="date_time" <?php if($event_heading == "date_time"): ?> selected <?php endif; ?>>Date/Time</option>
                                        <option value="interest_ranking" <?php if($event_heading == "interest_ranking"): ?> selected <?php endif; ?>>Interest Ranking</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <?php ($sort_order = app('request')->input('sort')); ?>
                                    <input type="radio" id="ascending" name="sort" value="asc" <?php if(!$sort_order || $sort_order == "" || $sort_order == 'asc'): ?> checked <?php endif; ?>>
                                    <label for="ascending">Ascending</label><br>
                                    <input type="radio" id="descending" name="sort" value="desc" <?php if($sort_order == 'desc'): ?> checked <?php endif; ?>>
                                    <label for="descending">Descending</label><br>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-2.5 offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Search')); ?>

                                    </button>
                                </div>
                                <div class="col-md-2">
                                    <a href="<?php echo e(route('dashboard.event.index')); ?>" class="btn btn-secondary"><?php echo e(__('Reset')); ?></a>
                                </div>
                            </div>
                        </form>
                    <?php else: ?>
                        <?php echo e(__('You do not have any events...')); ?>

                    <?php endif; ?>

                    <div class="col-md-3 offset-1 float-right">
                        <a href="<?php echo e(route('dashboard.event.create')); ?>" class="btn btn-success float-right"><?php echo e(__('Create Event')); ?></a>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <?php if(count($events) > 0): ?>
                        <table class="table table-striped table-bordered">
                            <tr>
                                <th>Name</th><th>Description</th><th>Location</th><th>Date/Time</th><th>Interest Ranking</th>
                            </tr>

                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route("dashboard.event.edit", $event->id)); ?>"><?php echo e(Str::limit($event['name'], 50)); ?></a></td>
                                    <td><?php echo e(Str::limit($event['description'], 50)); ?></td>
                                    <td><?php echo e(Str::limit($event['location'], 50)); ?></td>
                                    <td><?php echo e($event['date_time']->format("d-m-Y H:i")); ?></td>
                                    <td><?php echo e($event['interest_ranking']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bradl\XAMPP\htdocs\AstonEvents\resources\views/organiser/dashboard.blade.php ENDPATH**/ ?>