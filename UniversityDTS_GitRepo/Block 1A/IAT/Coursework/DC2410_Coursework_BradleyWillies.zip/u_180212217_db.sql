-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 22, 2021 at 03:05 PM
-- Server version: 5.7.34-0ubuntu0.18.04.1
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u_180212217_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organiser_id` bigint(20) UNSIGNED NOT NULL,
  `event_category_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_time` datetime NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `interest_ranking` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `related_event_id` bigint(20) UNSIGNED DEFAULT NULL,
  `web_source_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `organiser_id`, `event_category_id`, `name`, `date_time`, `description`, `location`, `interest_ranking`, `created_at`, `updated_at`, `related_event_id`, `web_source_url`) VALUES
(1, 1, 1, 'Letterpress Setters Operatorquos', '2015-12-11 19:44:33', 'Dicta et quibusdam voluptate sint alias doloribus voluptas voluptatem. Quam consequuntur molestias earum velit. Voluptate atque eos laborum aut et et et. Voluptatem aut labore ducimus ut.', 'Marvin Fall', 10, '2021-06-22 12:54:28', '2021-06-22 12:54:28', 6, 'http://www.daniel.com/pariatur-molestias-vel-corporis-ut-quo-perferendis-modi-consequatur'),
(2, 1, 1, 'Hand Sewerest', '1984-07-30 06:16:01', 'Tempore doloremque voluptatem voluptate nesciunt rem. Fuga sint animi dolores eligendi aperiam. Temporibus id eaque rerum occaecati. Quia rerum itaque deserunt blanditiis eius sit adipisci.', 'Jaskolski Estate', 3, '2021-06-22 12:54:28', '2021-06-22 12:54:28', 5, 'http://tromp.com/'),
(3, 2, 3, 'Curatordolor', '2013-05-21 00:38:19', 'Deleniti accusamus iste quisquam. Laborum ut unde et quae aliquam sed ea. Eius dolores temporibus ea hic rerum. Repellendus unde omnis et ratione libero.', 'Lueilwitz Parkways', 2, '2021-06-22 12:54:28', '2021-06-22 12:54:28', 1, 'http://von.com/'),
(4, 2, 3, 'Marking Clerkqui', '2018-04-20 07:57:20', 'Vero molestiae et perferendis odio. Ut quia quo optio minima quia dolorem reiciendis. Ut facilis fugiat quibusdam eius velit rerum qui.', 'Nienow Course', 9, '2021-06-22 12:54:28', '2021-06-22 12:54:28', 6, 'http://friesen.com/'),
(5, 3, 1, 'Educational Psychologistenim', '1991-10-22 04:59:55', 'Quis sunt quo sit doloribus. Vel possimus totam quia id. Repudiandae omnis molestiae suscipit esse eaque asperiores. Quis quod quas natus nobis. Quis sint esse aut officia ullam aut veniam voluptates.', 'Hyatt Tunnel', 4, '2021-06-22 12:54:28', '2021-06-22 12:54:28', 2, 'http://www.larson.com/non-voluptatem-consequatur-voluptatem-fugiat-distinctio-sunt-aliquam'),
(6, 3, 2, 'Actuaryquo', '1995-10-28 14:15:37', 'Asperiores ut et tenetur in ipsam ex et. Quia quo corporis nihil laborum aspernatur eius. Quia velit doloremque repudiandae cum. Voluptates repellendus laborum voluptas at adipisci adipisci dolor.', 'Idella Mews', 10, '2021-06-22 12:54:28', '2021-06-22 12:54:28', 1, 'http://pfeffer.net/'),
(7, 4, 2, 'Spraying Machine Operatorest', '2005-02-09 13:59:38', 'Corporis animi beatae vel est rerum molestiae. Culpa voluptates distinctio voluptatibus illo consectetur. Omnis et quia inventore amet voluptatem eligendi. Rerum consequuntur et veritatis dicta dignissimos tenetur.', 'Sporer Port', 8, '2021-06-22 12:54:28', '2021-06-22 12:54:28', 2, 'http://nikolaus.org/et-ut-dolorem-doloribus-quo'),
(8, 4, 1, 'Motorboat Mechanicnulla', '1998-08-17 17:43:22', 'Enim consequuntur maxime cupiditate architecto sint veniam. Architecto eaque repudiandae nobis odio libero voluptatem cum ea. Illo minima quae et odit quidem molestiae totam voluptatibus. Doloremque aspernatur sed ipsam accusantium dolor dolore voluptatem non.', 'Altenwerth Crossing', 6, '2021-06-22 12:54:28', '2021-06-22 12:54:28', 5, 'https://www.friesen.com/rerum-a-temporibus-quaerat-nihil-doloribus-excepturi-modi');

-- --------------------------------------------------------

--
-- Table structure for table `event_categories`
--

CREATE TABLE `event_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `event_categories`
--

INSERT INTO `event_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Sport', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(2, 'Culture', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(3, 'Other', '2021-06-22 12:54:28', '2021-06-22 12:54:28');

-- --------------------------------------------------------

--
-- Table structure for table `event_images`
--

CREATE TABLE `event_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `event_images`
--

INSERT INTO `event_images` (`id`, `event_id`, `file_path`, `created_at`, `updated_at`) VALUES
(1, 1, 'event_images/seed/event1.jpg', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(2, 2, 'event_images/seed/event1.jpg', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(3, 3, 'event_images/seed/event1.jpg', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(4, 4, 'event_images/seed/event1.jpg', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(5, 5, 'event_images/seed/event1.jpg', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(6, 6, 'event_images/seed/event2.jpg', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(7, 7, 'event_images/seed/event2.jpg', '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(8, 8, 'event_images/seed/event2.jpg', '2021-06-22 12:54:28', '2021-06-22 12:54:28');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_05_25_192241_create_organisers_table', 1),
(5, '2021_05_25_192327_create_event_categories_table', 1),
(6, '2021_05_25_192400_create_events_table', 1),
(7, '2021_05_25_192450_create_images_table', 1),
(8, '2021_05_25_205008_alter_organisers_table_make_phone_nullable', 1),
(9, '2021_06_03_174107_alter_events_table_make_description_text', 1),
(10, '2021_06_10_180128_alter_images_table_rename_to_event_images', 1),
(11, '2021_06_12_103612_alter_events_table_add_related_event_and_website', 1);

-- --------------------------------------------------------

--
-- Table structure for table `organisers`
--

CREATE TABLE `organisers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `organisers`
--

INSERT INTO `organisers` (`id`, `name`, `phone`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Prof. Turner Cremin', '+14198350664', 1, '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(2, 'Mr. Stephon Boyer Sr.', '254.992.0351', 2, '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(3, 'Dr. Chad Kilback DVM', '951-405-9311', 3, '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(4, 'Bob Smith', '754.923.0969', 4, '2021-06-22 12:54:28', '2021-06-22 12:54:28');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'gaylord57@example.net', NULL, '$2y$10$6n36fLXXsWOJZyTEpUONnuNEjzU6NeeUBeUwzy1onEePh5QXc1K5q', NULL, '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(2, 'igleason@example.org', NULL, '$2y$10$nwhh92ypCyYkwO6yp8LzX.88XWeMFoFhfHoCWfEmVyLdaoziloMsC', NULL, '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(3, 'xblock@example.org', NULL, '$2y$10$A2qPamFX2XPoOeHND1GIL.Od4opBf/cOzYJyQcHZPNbAeqCUbOQ5G', NULL, '2021-06-22 12:54:28', '2021-06-22 12:54:28'),
(4, 'bob.smith@email.com', NULL, '$2y$10$kA.cnsmiprL7iPq.DnqNW.BX8cXKUO5RT5wssy2UeYfmICQFCjU4O', NULL, '2021-06-22 12:54:28', '2021-06-22 12:54:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `events_organiser_id_foreign` (`organiser_id`),
  ADD KEY `events_event_category_id_foreign` (`event_category_id`);

--
-- Indexes for table `event_categories`
--
ALTER TABLE `event_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_images`
--
ALTER TABLE `event_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `images_event_id_foreign` (`event_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organisers`
--
ALTER TABLE `organisers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `organisers_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `event_categories`
--
ALTER TABLE `event_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `event_images`
--
ALTER TABLE `event_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `organisers`
--
ALTER TABLE `organisers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_event_category_id_foreign` FOREIGN KEY (`event_category_id`) REFERENCES `event_categories` (`id`),
  ADD CONSTRAINT `events_organiser_id_foreign` FOREIGN KEY (`organiser_id`) REFERENCES `organisers` (`id`);

--
-- Constraints for table `event_images`
--
ALTER TABLE `event_images`
  ADD CONSTRAINT `images_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`);

--
-- Constraints for table `organisers`
--
ALTER TABLE `organisers`
  ADD CONSTRAINT `organisers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
