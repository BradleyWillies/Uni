<?php

namespace Database\Seeders;

use App\Models\Organiser;
use Faker\Factory as Faker;
use Illuminate\Database\Seeder;

class OrganiserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();

        echo "Generating organisers...\n";
        for ($i = 1 ; $i <= 3 ; $i++) {
            Organiser::create([
                'name' => $faker->name,
                'phone' => $faker->phoneNumber,
                'user_id' => $i
            ]);
        }
        Organiser::create([
            'name' => 'Bob Smith',
            'phone' => $faker->phoneNumber,
            'user_id' => 4
        ]);
    }
}
