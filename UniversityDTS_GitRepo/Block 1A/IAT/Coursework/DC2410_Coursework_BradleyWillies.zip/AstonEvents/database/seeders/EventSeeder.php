<?php

namespace Database\Seeders;

use App\Models\Event;
use App\Models\EventImage;
use App\Models\User;
use Faker\Factory as Faker;
use Illuminate\Database\Seeder;

class EventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        $users = User::all();
        $eventCount = 0;

        echo "Generating events...\n";
        foreach ($users as $user) {
            for ($i = 0 ; $i < 2 ; $i++) {
                $eventCount++;
                Event::create([
                    'name' => $faker->jobTitle . $faker->word,
                    'description' => $faker->paragraph,
                    'location' => $faker->streetName,
                    'event_category_id' => $faker->numberBetween($min = 1, $max = 3),
                    'date_time' => $faker->dateTime,
                    'related_event_id' => $faker->numberBetween($min = 1, $max = 6),
                    'web_source_url' => $faker->url,
                    'organiser_id' => $user->id,
                    'interest_ranking' => $faker->numberBetween($min = 1, $max = 10)
                ]);
                EventImage::create([
                    'event_id' => $eventCount,
                    'file_path' => "event_images/seed/event" . $faker->numberBetween($min = 1, $max = 2) . ".jpg"
                ]);
            }
        }
    }
}
