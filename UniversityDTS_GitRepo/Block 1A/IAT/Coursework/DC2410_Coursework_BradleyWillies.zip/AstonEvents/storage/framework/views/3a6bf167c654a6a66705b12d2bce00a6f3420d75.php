<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><a href="<?php echo e(route('dashboard.event.index')); ?>">Dashboard</a> -> <?php echo e(__('Update Event')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('dashboard.event.update', $event->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name') ? : $event->name); ?>" required autocomplete="name" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                                <textarea id="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" required autocomplete="description" autofocus><?php echo e(old('description') ? : $event->description); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="location" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Location')); ?></label>

                            <div class="col-md-6">
                                <input id="location" type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="location" value="<?php echo e(old('location') ? : $event->location); ?>" required autocomplete="location" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="event_category_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Category')); ?></label>

                            <div class="col-md-6">
                                <select name="event_category_id" id="event_category_id" required>
                                    <?php $__currentLoopData = $eventCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($eventCategory->id); ?>" <?php if((old("event_category_id") ? : $event->event_category_id) == $eventCategory->id): ?> selected <?php endif; ?>><?php echo e($eventCategory->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="date_time" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date/Time')); ?></label>

                            <div class="col-md-6">
                                <input id="date_time" type="datetime-local" class="form-control <?php $__errorArgs = ['date_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date_time" value="<?php echo e(old('date_time') ? : $event->date_time->format("Y-m-d\TH:i")); ?>" required autocomplete="date_time" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="images" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Event Image(s)')); ?></label>

                            <div class="col-md-6">
                                <input id="images" type="file" class="form-control <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="images[]" autofocus multiple>
                                <small style="font-size: 10px">Select multiple images from the explorer / finder by holding ctrl / ⌘</small>
                                <small style="font-size: 10px">Existing images will be overwritten by new images</small>
                                <?php $__currentLoopData = $event->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <image src="<?php echo e(url('storage/' . $image->file_path)); ?>" alt="Event image" width="100" height="100"></image>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="related_event_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Related Event')); ?></label>

                            <div class="col-md-6">
                                <select name="related_event_id" id="related_event_id">
                                    <option value="" ></option>
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currentEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($currentEvent->id); ?>" <?php if((old("related_event_id") ? : $event->related_event_id) == $currentEvent->id): ?> selected <?php endif; ?>><?php echo e($currentEvent->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="web_source_url" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Related Website URL')); ?></label>

                            <div class="col-md-6">
                                <input id="web_source_url" type="text" class="form-control <?php $__errorArgs = ['web_source_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="web_source_url" value="<?php echo e(old('web_source_url') ?  : $event->web_source_url); ?>" autocomplete="web_source_url" autofocus>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-2 offset-md-4">
                                <a href="<?php echo e(route('dashboard.event.index')); ?>" class="btn btn-secondary"><?php echo e(__('Cancel')); ?></a>
                            </div>
                            <div class="col-md-3 offset-md-1">
                                <button type="submit" class="btn btn-primary float-right">
                                    <?php echo e(__('Update Event')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bradl\XAMPP\htdocs\AstonEvents\resources\views/organiser/event/show.blade.php ENDPATH**/ ?>